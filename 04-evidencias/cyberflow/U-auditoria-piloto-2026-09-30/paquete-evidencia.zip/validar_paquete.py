"""Verificación exclusivamente local y de lectura; no importa otros scripts."""
import collections
import csv
import hashlib
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFIESTO.json").read_text(encoding="utf-8"))
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    for name, expected in manifest["outputs_sha256"].items():
        assert digest(root / name) == expected, name

    def load(name):
        with (root / name).open(encoding="utf-8", newline="") as stream:
            return list(csv.DictReader(stream))

    key = lambda row: tuple(row[k] for k in ("campaign_id", "entity_ip", "window_end_utc"))
    original = load("ataques-nota-M.csv")
    cross = load("cruce-84-sin-correccion.csv")
    sensitivity = load("sensibilidad-offsets.csv")
    comparison = load("comparacion-sensores.csv")
    keys = {key(row) for row in original}
    assert len(original) == len(keys) == len(cross) == 84
    assert {key(row) for row in cross} == keys
    assert len(sensitivity) == 336
    totals = {}
    for offset in ("0", "-18", "-16", "-14"):
        rows = [row for row in sensitivity if row["offset_episodio_s"] == offset]
        assert len(rows) == 84 and {key(row) for row in rows} == keys
        assert all(row["etiqueta_original_sin_cambiar"] == "1" for row in rows)
        totals[offset] = dict(collections.Counter(row["estado_temporal"] for row in rows))
    summary = json.loads((root / "VERIFICACION.json").read_text(encoding="utf-8"))
    assert totals == summary["sensitivity_totals"]
    assert len(comparison) == 84
    assert sum(int(row["s2_active_match"]) for row in comparison) == 80
    assert sum(row["s2_active_match"] == "1" and
               float(row["s1_packet_count_10s"]) == float(row["s2_packet_count_10s"])
               for row in comparison) == 37
    print(json.dumps({
        "verified_manifest_hashes": len(manifest["outputs_sha256"]),
        "original_rows": len(original), "cross_rows": len(cross),
        "sensitivity_rows": len(sensitivity), "totals": totals,
        "pending_manifest_entries": {
            p.name: digest(p) for p in sorted(root.iterdir())
            if p.is_file() and p.name != "MANIFIESTO.json"
            and p.name not in manifest["outputs_sha256"]
        },
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
