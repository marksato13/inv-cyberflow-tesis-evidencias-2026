"""Cruce de las 84 ventanas del piloto 30-sep con episodios, desfase Sensor1-Kali = -16 s medido."""
import csv, sys
from datetime import datetime, timedelta, timezone

d = sys.argv[1]
OFF = timedelta(seconds=-16)          # hora Sensor1 = hora Kali - 16 s (medido en E2, E4, E5, E6, inicio E3)
TOL = timedelta(seconds=2)
def k(hms): return datetime.fromisoformat("2026-09-30T%s+00:00" % hms)
# episodios en hora KALI (bitacoras); E0 reconstruido (sin bitacora)
EP = [
    ("E0", "nmap -sT -sV -p- manual (historial zsh l.79; sesion SSH 00:12:18)", k("00:12:18"), k("00:15:46"), "reconstruido"),
    ("E1", "nmap atacar.sh", k("00:31:05"), k("00:32:46"), "bitacora"),
    ("E2", "Nikto atacar.sh", k("00:33:46"), k("00:35:48"), "bitacora"),
    ("E3", "Nikto atacar2.sh (rc=124)", k("01:22:46"), k("01:25:16"), "bitacora"),
    ("E4", "brute-force HTTP", k("01:25:46"), k("01:27:46"), "bitacora"),
    ("E5", "password-spray", k("01:28:16"), k("01:28:18"), "bitacora"),
    ("E6", "dns-entropy", k("01:28:48"), k("01:31:00"), "bitacora"),
]
EP = [(i, n, a + OFF, b + OFF, f) for i, n, a, b, f in EP]   # a hora Sensor1
# NTP de la Kali (timesyncd): sincronizacion inicial 00:11:37 Kali y sondeos 2 paquetes
NTP = {"00:11:30", "00:19:00", "00:27:30", "00:44:30", "01:18:40", "01:52:50"}
# probable gestion SSH desde el bastion (sesion 486 + reboot; tecleo antes de lanzar guiones)
GEST = {"00:10:10": "sesion SSH 486 (00:10:12-00:10:48 Kali) y sudo reboot",
        "00:10:20": "sesion SSH 486 (00:10:12-00:10:48 Kali) y sudo reboot"}

lin = open(d + "/notaM-claves.txt", encoding="utf-8").read().splitlines()[1:]
claves = [r for r in csv.DictReader(lin) if r.get("window_end_utc")]
s1 = {r["window_end_utc"]: r for r in csv.DictReader(open(d + "/s1-piloto.csv", encoding="utf-8")) if r["entity_ip"] == "10.10.20.30"}
s2 = {}
for r in csv.DictReader(open(d + "/s2-piloto.csv", encoding="utf-8")):
    if r["entity_ip"] == "10.10.20.30":
        t = datetime.fromisoformat(r["window_end_utc"]) + timedelta(seconds=180)   # S2 = S1 - 180 s
        s2[t.isoformat()] = r

filas, cuenta = [], {}
for n, c in enumerate(sorted(claves, key=lambda r: r["window_end_utc"]), 1):
    w = datetime.fromisoformat(c["window_end_utc"]); hh = w.strftime("%H:%M:%S")
    r = s1[c["window_end_utc"]]; r2 = s2.get(w.isoformat())
    ini = w - timedelta(seconds=10)
    propio = [e for e in EP if e[2] - TOL < w and e[3] + TOL > ini]
    cruza = {}
    for L in (10, 30, 60):
        a = w - timedelta(seconds=L)
        cruza[L] = sorted({e[0] + ("ini" if a < e[2] <= w else "") + ("fin" if a < e[3] <= w else "") for e in EP if (a < e[2] <= w) or (a < e[3] <= w)})
    frontera = any(abs(w - e[2]) <= TOL or abs(ini - e[2]) <= TOL or abs(w - e[3]) <= TOL or abs(ini - e[3]) <= TOL for e in propio)
    if propio:
        cat = "T0" if propio[0][4] == "reconstruido" else "T"
        ep = "+".join(e[0] for e in propio)
    elif hh in NTP:
        cat, ep = "N", "NTP Kali"
    elif hh in GEST:
        cat, ep = "G", GEST[hh]
    elif any(cruza[L] for L in (10, 30, 60)):
        cat, ep = "R", "solo por retrospectiva"
    else:
        cat, ep = "U", "sin episodio"
    if cat in ("T", "T0") and frontera: cat += "f"
    cuenta[cat] = cuenta.get(cat, 0) + 1
    filas.append((n, hh, r["packet_count_10s"], r["syn_count_10s"], r["http_request_count_60s"], r["dns_query_count_60s"],
                  (r2["packet_count_10s"] if r2 else "—"), cat, ep,
                  ", ".join("%ds:%s" % (L, "/".join(cruza[L])) for L in (10, 30, 60) if cruza[L]) or "—"))
print("| # | Ventana S1 (fin, UTC) | paq/10s | SYN/10s | HTTP/60s | DNS/60s | S2 paq (−180 s) | Cat. | Episodio / explicación | Retrospectiva que cruza inicio/fin |")
print("|---|---|---|---|---|---|---|---|---|---|")
for f in filas: print("| %d | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % f)
print("\nRECUENTO", dict(sorted(cuenta.items())))
pares = sum(1 for f in filas if f[6] != "—"); print("con pareja en Sensor2:", pares, "de", len(filas))
