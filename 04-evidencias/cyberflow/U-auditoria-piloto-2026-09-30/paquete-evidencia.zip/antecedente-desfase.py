import csv, sys
from datetime import datetime, timedelta
d = sys.argv[1]
def serie(f, ip="10.10.20.30"):
    s = {}
    for r in csv.DictReader(open(f, encoding="utf-8")):
        if r["entity_ip"] == ip and "2026-09-30T00:00" <= r["window_end_utc"] < "2026-09-30T02:00":
            v = float(r["packet_count_10s"] or 0)
            if v > 0: s[datetime.fromisoformat(r["window_end_utc"])] = (v, r)
    return s
a, b = serie(d + "/s1-piloto.csv"), serie(d + "/s2-piloto.csv")
res = []
for k in range(-60, 61):            # desplazamiento de S2 en segundos
    sh = {t + timedelta(seconds=k): v for t, v in b.items()}
    comunes = set(a) & set(sh)
    res.append((len(comunes), k))
res.sort(reverse=True); print("mejores desplazamientos (coincidencias, segundos a sumar a S2):", res[:5])
best = res[0][1]
sh = {t + timedelta(seconds=best): v for t, v in b.items()}
comunes = sorted(set(a) & set(sh))
print("con %+ds: %d de 84 coinciden" % (best, len(comunes)))
iguales = sum(1 for t in comunes if a[t][0] == sh[t][0])
print("packet_count_10s identico en", iguales, "de", len(comunes))
for t in comunes[:4] + comunes[-3:]:
    print(" ", t.time(), "S1", a[t][0], "S2", sh[t][0], "| syn S1/S2", a[t][1]["syn_count_10s"], sh[t][1]["syn_count_10s"], "| http60 S1/S2", a[t][1]["http_request_count_60s"], sh[t][1]["http_request_count_60s"])
falt = sorted(set(a) - set(sh)); print("S1 sin pareja:", [t.strftime("%H:%M:%S") for t in falt][:12])
