"""Audita fuentes existentes; solo lecturas remotas. Escribe solo este paquete local.

No ejecuta generadores, no importa extractores ni carga modelos. No cambia etiquetas.
Las alineaciones de series no son mediciones independientes de relojes.
"""
import csv
import datetime as dt
import hashlib
import io
import json
from pathlib import Path
import shlex
import subprocess

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "CRUCE-PILOTO-2026-09-30-EVIDENCIA"
PRODUCT = Path(r"C:\Users\markp\Desktop\PY-MEGATRON\PY - PERSONAL\TESIS\CYBERFLOW\producto-main")
REV = "83599c9e000746af5ba3647ae89ec39e6fb026f5"
SSH = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=12", "-o", "StrictHostKeyChecking=yes",
       "-i", str(Path.home() / ".ssh/id_ed25519"), "gadmin@10.10.10.30"]
KEY = ("campaign_id", "entity_ip", "window_end_utc")
EP = [("E1", "nmap", "00:31:05", "00:32:46"), ("E2", "Nikto1", "00:33:46", "00:35:48"),
      ("E3", "Nikto2_timeout", "01:22:46", "01:25:16"), ("E4", "HTTP_bucle", "01:25:46", "01:27:46"),
      ("E5", "password_spray", "01:28:16", "01:28:18"), ("E6", "DNS", "01:28:48", "01:31:00")]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, raw):
    path = HERE / name
    if isinstance(raw, str):
        raw = raw.encode("utf-8")
    if path.exists() and path.name != "MANIFIESTO.json":
        assert path.read_bytes() == raw, "No sobrescribir resultados distintos: " + name
    else:
        path.write_bytes(raw)
    return sha(raw)


def fetch(command, user=None, host=None, identity=None):
    if host:
        command = "ssh -o BatchMode=yes -o ConnectTimeout=12 -o StrictHostKeyChecking=yes -i " + identity + " " + user + "@" + host + " " + shlex.quote(command)
    return subprocess.check_output(SSH + [command], timeout=90)


def sensor(command):
    return fetch(command, "m4rk", "10.10.60.11", "~/.ssh/cyberflow-to-sensor")


def utc(value):
    return dt.datetime.fromisoformat("2026-09-30T" + value + "+00:00")


def parse(raw):
    return list(csv.DictReader(io.StringIO(raw.decode("utf-8"))))


def csv_bytes(data):
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=list(data[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(data)
    return buffer.getvalue()


def main():
    sources = {}
    original = sensor("cat /home/m4rk/cyberflow/artifacts/aprendizaje/ataques/ataques-nota-M.csv")
    assert sha(original) == "4affd07fff45f97c91eb531f208d76df0410fbb602ea1b13847336dfb0e2803e"
    sources["sensor1:/home/m4rk/cyberflow/artifacts/aprendizaje/ataques/ataques-nota-M.csv"] = save("ataques-nota-M.csv", original)
    windows = sorted(parse(original), key=lambda r: r["window_end_utc"])
    assert len(windows) == len({tuple(r[k] for k in KEY) for r in windows}) == 84
    for name, expected in (("ataques-cyberflow-20260929-193105.txt", "fe5bdadca0c88e10c50c0f601c12aac43faf3c13c7e18ae177765cf4a2882fd1"),
                           ("ataques2-20260929-202246.txt", "7609f3d1c625e5b2fa30dd842025a81b950d5f2fae70911366d5ede5b0f84971")):
        raw = fetch("cat /home/adminatacante/" + name, "adminatacante", "10.10.20.30", "~/.ssh/cyberflow-to-atacante")
        assert sha(raw) == expected
        sources["kali:/home/adminatacante/" + name] = save(name, raw)
    for name in ("sensor1.txt", "hosts-bastion.txt", "inventario-pcap-eve-sensor1.txt"):
        raw = fetch("cat /tmp/cf-adenda/" + name)
        sources["bastion:/tmp/cf-adenda/" + name] = save(name, raw)
    for name in ("s1-piloto.csv", "s2-piloto.csv", "kali-journal-piloto.txt", "kali-zsh-50-140.txt", "sensor2-tiempo.txt", "cruce.py", "desfase.py"):
        raw = (OLD / name).read_bytes()
        sources[str(OLD / name)] = save("antecedente-" + name, raw)

    historical = {}
    for name in ("extract_multilayer_v2.py", "extract_multilayer_v3.py", "acumular_v3.py"):
        rel = "scripts/features/" + name
        raw = subprocess.check_output(["git", "-C", str(PRODUCT), "cat-file", "blob", REV + ":" + rel])
        historical[name] = sha(raw)
        sources[REV + ":" + rel] = save("historico-" + name, raw)
    # Metadatos y hashes de copias existentes; no se importan ni se ejecutan.
    code = '''from pathlib import Path
import hashlib,json
for root in [Path('/home/m4rk/cyberflow'),Path('/home/m4rk/cyberflow.k-20260929')]:
 for name in ['extract_multilayer_v2.py','extract_multilayer_v3.py','acumular_v3.py']:
  p=root/'scripts/features'/name
  if p.is_file():
   raw=p.read_bytes(); print(json.dumps({'path':str(p),'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mtime':p.stat().st_mtime}))
'''
    raw = fetch("python3 -B -c " + shlex.quote(code), "m4rk", "10.10.60.12", "~/.ssh/cyberflow-to-sensor")
    sources["sensor2:hashes_copias_codigo"] = save("sensor2-codigo-hashes.jsonl", raw)
    raw = sensor("python3 -B -c " + shlex.quote(code))
    sources["sensor1:hashes_codigo_actual_no_prueba_despliegue_historico"] = save("sensor1-codigo-hashes.jsonl", raw)
    # Medir coincidencias activas, no meramente presencia de una fila con score 0.
    a = {r["window_end_utc"]: r for r in parse((OLD / "s1-piloto.csv").read_bytes()) if r["entity_ip"] == "10.10.20.30" and float(r["packet_count_10s"]) > 0}
    b = {r["window_end_utc"]: r for r in parse((OLD / "s2-piloto.csv").read_bytes()) if r["entity_ip"] == "10.10.20.30" and float(r["packet_count_10s"]) > 0}
    alignments = []
    for shift in range(-600, 601, 10):
        shifted = {(dt.datetime.fromisoformat(t) + dt.timedelta(seconds=shift)).isoformat(): r for t, r in b.items()}
        common = sorted(a.keys() & shifted.keys())
        alignments.append({"seconds_added_to_s2": shift, "active_keys_common": len(common),
                           "identical_packet_counts": sum(a[t]["packet_count_10s"] == shifted[t]["packet_count_10s"] for t in common)})
    best = sorted(alignments, key=lambda r: (r["active_keys_common"], r["identical_packet_counts"]), reverse=True)
    save("alineacion-series.csv", csv_bytes(alignments))
    comparison = []
    for row in windows:
        t = dt.datetime.fromisoformat(row["window_end_utc"])
        match = b.get((t - dt.timedelta(seconds=180)).isoformat())
        comparison.append({"window_end_s1": t.isoformat(), "s1_packet_count_10s": row["packet_count_10s"],
                           "window_end_s2_hypothesis": (t - dt.timedelta(seconds=180)).isoformat(),
                           "s2_active_match": int(match is not None), "s2_packet_count_10s": match["packet_count_10s"] if match else "",
                           "status": "alineacion_exploratoria_no_medicion_reloj"})
    save("comparacion-sensores.csv", csv_bytes(comparison))
    records, totals = [], {}
    for offset in (0, -18, -16, -14):
        counts = {"cierre_dentro": 0, "solo_historia": 0, "sin_intervalo": 0}
        for index, row in enumerate(windows, 1):
            t = dt.datetime.fromisoformat(row["window_end_utc"])
            intervals = [(n, desc, utc(start) + dt.timedelta(seconds=offset), utc(end) + dt.timedelta(seconds=offset)) for n, desc, start, end in EP]
            during = [n for n, _, start, end in intervals if start <= t <= end]
            overlap = lambda w: [n for n, _, start, end in intervals if t >= start and t - dt.timedelta(seconds=w) < end]
            history = overlap(60)
            state = "cierre_dentro" if during else ("solo_historia" if history else "sin_intervalo")
            counts[state] += 1
            record = {"id": index, **{k: row[k] for k in KEY}, "etiqueta_original_sin_cambiar": 1,
                      "offset_episodio_s": offset, "offset_status": "sin_correccion" if offset == 0 else "hipotesis_no_medida_independientemente",
                      "episodios_cierre": ";".join(during), "estado_temporal": state,
                      "estado_verificacion": "incierta_atribucion_no_confirmada_con_trafico_crudo",
                      **{k: row[k] for k in ("packet_count_10s", "syn_count_10s", "flow_attempt_count_30s", "http_request_count_60s", "dns_query_count_60s")}}
            for w in (10, 30, 60):
                record[f"overlap_{w}s"] = ";".join(overlap(w))
                record[f"cruza_inicio_{w}s"] = ";".join(n for n, _, start, end in intervals if t-dt.timedelta(seconds=w) < start <= t)
                record[f"cruza_fin_{w}s"] = ";".join(n for n, _, start, end in intervals if t-dt.timedelta(seconds=w) < end < t)
            records.append(record)
        totals[str(offset)] = counts
    save("cruce-84-sin-correccion.csv", csv_bytes([r for r in records if r["offset_episodio_s"] == 0]))
    save("sensibilidad-offsets.csv", csv_bytes(records))
    summary = {"original_csv_sha256": sha(original), "n": 84, "historical_candidate_commit": REV,
               "historical_code_sha256": historical, "historical_deployment_proven": False,
               "alignment_top10": best[:10], "s2_active_match_at_plus180": sum(r["s2_active_match"] for r in comparison),
               "s2_identical_packet_counts_at_plus180": sum(bool(r["s2_active_match"]) and r["s1_packet_count_10s"] == r["s2_packet_count_10s"] for r in comparison),
               "sensitivity_totals": totals, "offset_s1_kali_independently_measured": False,
               "ntp_classification_confirmed_per_window": False, "E0_exact_start_end_known": False,
               "labels_changed": False, "classification_metrics_recomputed": False}
    save("VERIFICACION.json", json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    manifest = {"generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "sources_sha256": sources,
                "remote_operations": "Solo cat y Python estándar de lectura de copias; sin escrituras remotas intencionadas",
                "outputs_sha256": {p.name: sha(p.read_bytes()) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != "MANIFIESTO.json"},
                "labels_changed": False, "metrics_changed": False}
    save("MANIFIESTO.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
