"""Inventario de lectura para investigar evidencia en VMs apagadas."""
import importlib.util
from pathlib import Path
import concurrent.futures
import sys
import base64
import json
import subprocess

spec=importlib.util.spec_from_file_location('adquisicion',r'C:\Users\markp\Downloads\R1.3-CIERRE-EVIDENCIA-PILOTO\recuperar.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ROOT=Path(__file__).resolve().parent

def inventory():
    tooling="id; date -u; command -v guestfish guestmount virt-filesystems qemu-img qemu-nbd nbdkit sshfs python3; df -h /home /tmp; sudo -n -l"
    esxi="date -u; vim-cmd vmsvc/getallvms; for id in 2 8 10; do echo VMID=$id; vim-cmd vmsvc/power.getstate $id; vim-cmd vmsvc/snapshot.get $id; done; ls -ln /vmfs/volumes/datastore1/VM-WAZUH/*.vmdk /vmfs/volumes/datastore1/VM_ZABBIX/*.vmdk /vmfs/volumes/datastore1/VM-SURICATA-CYBERFLOW/*.vmdk"
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        jobs=[ex.submit(module.acquire,'01-bastion-herramientas',tooling),ex.submit(module.acquire,'02-hv-siem-vms-discos',esxi,'root','esxi-hv-siem','~/.ssh/francos-red-export')]
        for j in jobs:j.result()

def capabilities():
    code="""import importlib.util,json,sys
for name in ['paramiko','dissect','pytsk3','pip']:
 print(json.dumps({'module':name,'available':importlib.util.find_spec(name) is not None}))
print(sys.version)
"""
    descriptors="for pair in 'VM-WAZUH VM-WAZUH' 'VM_ZABBIX VM_ZABBIX' 'VM-SURICATA-CYBERFLOW VM-SURICATA-CYBERFLOW'; do set -- $pair; echo DISK=$1; cat /vmfs/volumes/datastore1/$1/$2.vmdk; grep -E 'fileName|present' /vmfs/volumes/datastore1/$1/$2.vmx | grep -E 'vmdk|scsi'; done"
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        jobs=[ex.submit(module.acquire,'03-python-capacidades',module.python_command(code)),ex.submit(module.acquire,'04-descriptores-discos',descriptors,'root','esxi-hv-siem','~/.ssh/francos-red-export')]
        for j in jobs:j.result()

def offline(vm):
    root=Path(__file__).resolve().parent
    wheels=Path(r'C:\Users\markp\AppData\Local\Temp\opencode\r13-wheels')
    params={'vm':vm}
    if len(sys.argv)>3:
        arg=sys.argv[3]
        if arg=='detalle':
            if vm=='wazuh':params.update({'capture':'detalle','filesystem':'lvm-wazuh-data','paths':['/volumes','/containers'],'walk':['/volumes'],'walk_depth':1})
            if vm=='zabbix':params.update({'capture':'detalle','filesystem':'partition-1','paths':['/srv','/var/log/zabbix','/var/log/postgresql','/var/lib/postgresql/17/main','/var/log/chrony','/etc/timezone'],'walk':['/srv','/var/backups'],'walk_depth':2})
            if vm=='suricata':params.update({'capture':'detalle','filesystem':'lvm-suricata-logs','paths':['/eve.json.1-2026101800.backup','/suricata.log.1-2026101800.backup'],'read_files':True})
        else:params.update(json.loads(Path(arg).read_text(encoding='utf-8')))
    payload={'wheels':{p.name:base64.b64encode(p.read_bytes()).decode() for p in wheels.glob('*py3-none-any.whl')},'source':(root/'lector_remoto.py').read_text(encoding='utf-8'),'params':params}
    bootstrap="""import sys,json,tempfile,pathlib,base64,zipfile,io
p=json.load(sys.stdin)
with tempfile.TemporaryDirectory(prefix='r13-reader-') as tmp:
 for name,encoded in p['wheels'].items():
  with zipfile.ZipFile(io.BytesIO(base64.b64decode(encoded))) as archive:
   assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in archive.namelist())
   archive.extractall(tmp)
 sys.path.insert(0,tmp)
 exec(compile(p['source'],'lector_remoto.py','exec'),{'PARAMS':p['params']})
"""
    import shlex,datetime,hashlib
    suffix=params.get('capture','inventario-v2')
    target=root/('offline-'+vm+'-'+suffix+'.json')
    assert not target.exists()
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(module.SSH+['python3 -B -c '+shlex.quote(bootstrap)],input=json.dumps(payload).encode(),capture_output=True,timeout=1800)
    data={'started_utc':start,'vm':vm,'parameters':params,'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stdout':result.stdout.decode(errors='replace'),'stderr':result.stderr.decode(errors='replace')}
    target.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'path':str(target),'returncode':result.returncode,'stdout_bytes':len(result.stdout),'stderr':data['stderr']},ensure_ascii=False))

if __name__=='__main__':
    if sys.argv[1:2]==['offline']: offline(sys.argv[2])
    elif sys.argv[1:]==['capabilities']: capabilities()
    else: inventory()
