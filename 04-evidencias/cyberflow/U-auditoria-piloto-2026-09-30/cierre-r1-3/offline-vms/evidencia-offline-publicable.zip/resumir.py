import json
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
for p in sorted(root.glob(sys.argv[1] if len(sys.argv)>1 else 'offline-*.json')):
 data=json.loads(p.read_text(encoding='utf-8'))
 print(p.name,'RC',data['returncode'])
 for line in data['stdout'].splitlines():
  row=json.loads(line)
  if 'entries' in row:
   print(row['filesystem'],row['directory'])
   for item in row['entries']:
    print(' ',item['path'],item['size'],item['mtime'])
  elif 'base64' in row:print({k:v for k,v in row.items() if k!='base64'})
  else:print(row)
