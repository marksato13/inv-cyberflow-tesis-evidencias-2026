"""Consolida evidencia offline sin consultar modelos ni modificar fuentes anteriores."""
import ast
import base64
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import random
import re
import zipfile

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'R1.3-CIERRE-EVIDENCIA-PILOTO'

def digest(raw):return hashlib.sha256(raw).hexdigest()

def save(name,raw):
 if isinstance(raw,str):raw=raw.encode('utf-8')
 p=ROOT/name
 if p.exists():assert p.read_bytes()==raw,name
 else:p.write_bytes(raw)
 return raw

def csv_bytes(rows):
 out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
 return out.getvalue().encode('utf-8')

def load_csv(path):return list(csv.DictReader(io.StringIO(path.read_text(encoding='utf-8'))))

def test_reader():
 # Compile just the adapter class, with an in-memory dd equivalent, without importing the acquisition module.
 tree=ast.parse((ROOT/'lector_remoto.py').read_text(encoding='utf-8'))
 cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RemoteDisk')
 content=bytes((i*37+19)%256 for i in range(200003))
 def remote(command):
  assert command.startswith('dd if=') and ' of=' not in command
  match=re.search(r'skip=(\d+)',command);index=int(match[1])
  return content[index*65536:(index+1)*65536]
 env={'io':io,'collections':collections,'remote':remote,'shlex':__import__('shlex')}
 exec(compile(ast.Module(body=[cls],type_ignores=[]),'adapter-test','exec'),env)
 reader=env['RemoteDisk']('/fixed/image',len(content))
 assert reader.writable() is False
 rng=random.Random(1337)
 for _ in range(200):
  start=rng.randrange(len(content)+1);length=rng.randrange(90000)
  reader.seek(start);assert reader.read(length)==content[start:start+length]
 reader.seek(-7,2);assert reader.read()==content[-7:]
 try:reader.seek(-1)
 except ValueError:pass
 else:raise AssertionError('negative seek accepted')
 return {'adapter_unaligned_eof_checks':202,'adapter_writable':False}

def build():
 test=test_reader()
 rows=load_csv(OLD/'MATRIZ-158.csv')
 for r in rows:
  r['evidencia_wazuh']='offline-wazuh-logs-catalogo;archives_alerts_Oct_Nov;Sep_no_localizado_en_rutas;indices_documentos_sin_consultar'
  r['evidencia_zabbix']='offline-zabbix-logs-contenido;rotaciones_extraidas_Nov12_15;tablas_history_trends_events_no_consultadas'
  r['evidencia_suricata_offline']='offline-suricata-detalle;96_eventos_EVE_2026-10-02;no_evidencia_piloto_en_archivo_inspeccionado'
 save('MATRIZ-158-OFFLINE.csv',csv_bytes(rows))
 source=load_csv(OLD/'FUENTES-Y-LIMITES.csv')
 for r in source:
  if r['fuente'].startswith('Wazuh'):
   r.update(estado='catalogos_offline_inspeccionados;documentos_indices_no_consultados',capturas='offline-wazuh-logs-catalogo;offline-wazuh-contenido-oct18',detalle='archives/alerts 2026 Oct y Nov; rutas Sep ausentes; alerta Oct18 con188 eventos de octubre',limite='sin_busqueda_semantica_Lucene;sin_recuperacion_borrados;no_prueba_ausencia_global')
  if r['fuente'].startswith('Zabbix'):
   r.update(estado='logs_offline_inspeccionados;tablas_historicas_no_consultadas',capturas='offline-zabbix-inventario-v2;offline-zabbix-logs-contenido',detalle='PostgreSQL17 localizado; logs extraidos Nov12_15;sin_eventos_del_piloto_en_esos_logs',limite='logs_arranque_no_demuestran_ausencia_historia_importada;sin_consulta_SQL')
 source.append({'fuente':'Suricata_VM_apagada','estado':'catalogos_y_respaldo_EVE_selectivo_inspeccionados','capturas':'offline-suricata-inventario-v2;offline-suricata-detalle;offline-suricata-mapa-final','detalle':'raiz_subyacente_y_LV_logs;respaldo76730bytes_96eventos_Oct2','limite':'no_todas_rotaciones_leidas;sin_carving;sin_atribucion_por_ventana_piloto'})
 save('FUENTES-Y-LIMITES-OFFLINE.csv',csv_bytes(source))
 entries={};content_records=[];controls=[];public={};extracted=0
 for p in sorted(ROOT.glob('*.json')):
  if not(p.name.startswith(('offline-','01-','02-','03-','04-'))):continue
  original=p.read_bytes();data=json.loads(original)
  if 'stdout'not in data:continue
  if p.name.startswith('offline-'):
   assert digest(data['stdout'].encode())==data['stdout_sha256']
   lines=[]
   for text in data['stdout'].splitlines():
    obj=json.loads(text)
    if 'filesystem'in obj and 'uuid'in obj:assert obj['s_state']==1 and not obj['feature_incompat']&4
    if obj.get('complete'):
     assert obj['disk_metadata_unchanged'] and 'Powered off'in obj['state_after']
     controls.append({'capture':p.name,'vm':data['vm'],'range_requests':obj['range_requests'],'bytes_read':obj['bytes_read']})
    if 'lvm_mapping'in obj:
     assert len(obj['physical_volume_ids'])==1
     for lv in obj['logical_segments'].values():
      for name,segment in lv.items():
       if isinstance(segment,dict):assert segment['stripe_count']==1
    if 'extracted_path'in obj:
     raw=base64.b64decode(obj.pop('base64'));assert len(raw)==obj['size'] and digest(raw)==obj['sha256']
     obj['raw_content_omitted_from_publication']=True;extracted+=1
    if obj.get('scanned_json_path'):
     assert 'error'not in obj
     content_records.append(obj)
    candidates=obj.get('entries',[])
    if obj.get('walk'):candidates=[obj]
    for e in candidates:
     entries[(data['vm'],obj['filesystem'],e['path'])]={'vm':data['vm'],'filesystem':obj['filesystem'],'path':e['path'],'size':e['size'],'type':e['type'],'mtime':e['mtime'],'evidence_kind':'metadata_not_event_timestamp'}
    lines.append(json.dumps(obj,ensure_ascii=True))
   if data['returncode']==0:assert lines and json.loads(lines[-1]).get('complete')
   data['original_capture_sha256']=digest(original)
   data['original_stdout_sha256']=data['stdout_sha256']
   data['stdout']='\n'.join(lines)+('\n'if lines else '')
   data['stdout_sha256']=digest(data['stdout'].encode())
   data['publication']='filtered_copy;application_log_base64_removed;not_literal_original_capture'
  public['capturas/'+p.name]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
 assert len(controls)==10,len(controls)
 save('INVENTARIO-OFFLINE.csv',csv_bytes([entries[k] for k in sorted(entries)]))
 summary={'successful_offline_captures':len(controls),'captured_errors_preserved':3,'controls':controls,
          'wazuh_content_scans':content_records,'files_with_raw_application_bytes_omitted':extracted,
          'all_window_keys_and_labels_preserved':True,'metrics_changed':False,'offsets_applied':[0],
          'integrity_scope':'spot_controls_no_full_disk_hash_no_atomic_image',**test}
 save('VERIFICACION-OFFLINE.json',json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 wheels=Path(r'C:\Users\markp\AppData\Local\Temp\opencode\r13-wheels')
 dependencies={p.name:digest(p.read_bytes())for p in sorted(wheels.glob('*py3-none-any.whl'))}
 save('DEPENDENCIAS-SHA256.json',json.dumps(dependencies,indent=2)+'\n')
 # Public package contains authored code and filtered evidence, not third-party wheels or raw application logs.
 for p in sorted(ROOT.iterdir()):
  if p.suffix in ['.py','.md'] or p.name.startswith('plan-')or p.name in ['MATRIZ-158-OFFLINE.csv','FUENTES-Y-LIMITES-OFFLINE.csv','INVENTARIO-OFFLINE.csv','VERIFICACION-OFFLINE.json','DEPENDENCIAS-SHA256.json','ANALISIS-CONTENIDO.json']:
   public[p.name]=p.read_bytes()
 package_manifest={'members_sha256':{k:digest(v)for k,v in sorted(public.items())},'previous_matrix_sha256':digest((OLD/'MATRIZ-158.csv').read_bytes()),'raw_application_logs_included':False}
 public['MANIFIESTO-PUBLICO.json']=(json.dumps(package_manifest,ensure_ascii=False,indent=2)+'\n').encode()
 archive=ROOT/'evidencia-offline-publicable.zip'
 assert not archive.exists()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for name,raw in sorted(public.items()):
   info=zipfile.ZipInfo(name,(2026,11,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw)
 save('MANIFIESTO-ENTREGA.json',json.dumps({'package_sha256':digest(archive.read_bytes()),'package_bytes':archive.stat().st_size,'package_members':len(public),'readable_outputs_sha256':{name:digest((ROOT/name).read_bytes())for name in ['INFORME-OFFLINE-R1.3.md','MATRIZ-158-OFFLINE.csv','FUENTES-Y-LIMITES-OFFLINE.csv','INVENTARIO-OFFLINE.csv','VERIFICACION-OFFLINE.json']},'source_previous_matrix_sha256':package_manifest['previous_matrix_sha256']},indent=2)+'\n')
 print(json.dumps({'package_members':len(public),'package_bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),'inventory_rows':len(entries),'controls':len(controls)},indent=2))

if __name__=='__main__':build()
