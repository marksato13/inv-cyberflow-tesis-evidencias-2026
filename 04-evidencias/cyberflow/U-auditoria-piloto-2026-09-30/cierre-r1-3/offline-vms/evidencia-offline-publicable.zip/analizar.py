"""Análisis local de capturas offline; nunca accede al laboratorio."""
import base64
import collections
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent

def main():
 findings=[]
 for capture in sorted(ROOT.glob('offline-*.json')):
  outer=json.loads(capture.read_text(encoding='utf-8'))
  if outer['returncode']!=0:continue
  rows=[json.loads(line) for line in outer['stdout'].splitlines()]
  assert rows[-1].get('complete') and rows[-1]['disk_metadata_unchanged']
  for r in rows:
   if 'extracted_path' in r:
    raw=base64.b64decode(r['base64']);assert hashlib.sha256(raw).hexdigest()==r['sha256']
    content=gzip.decompress(raw) if r['extracted_path'].endswith('.gz') else raw
    lines=content.decode('utf-8',errors='replace').splitlines()
    if 'eve.json' in r['extracted_path']:
     events=[json.loads(line) for line in lines if line.strip()]
     stamps=[e.get('timestamp','') for e in events]
     hits=[e for e in events if str(e.get('timestamp','')).startswith(('2026-09-27','2026-09-28','2026-09-29','2026-09-30'))]
     detail={'events':len(events),'timestamp_min':min(stamps,default=''),'timestamp_max':max(stamps,default=''),'september27_30':len(hits)}
    else:
     # Only event header dates, never dates mentioned in messages.
     date_pattern=r'^(?:\s*\d+:)?(?:202609(?:27|28|29|30):|2026-09-(?:27|28|29|30)|(?:27|28|29|30)/Sep/2026|Sep\s+(?:27|28|29|30)\b)'
     hits=[(i,line) for i,line in enumerate(lines,1) if re.search(date_pattern,line)]
     detail={'lines':len(lines),'first':lines[0] if lines else '', 'last':lines[-1] if lines else '', 'september27_30':len(hits),'matches':hits[:20]}
    findings.append({'capture':capture.name,'vm':outer['vm'],'filesystem':r['filesystem'],'path':r['extracted_path'],'raw_size':len(raw),'raw_sha256':r['sha256'],**detail})
 catalog=json.loads((ROOT/'offline-wazuh-logs-catalogo.json').read_text(encoding='utf-8'))
 data=[json.loads(s) for s in catalog['stdout'].splitlines()]
 errors=[r for r in data if 'error'in r and ('Sep'in r.get('path','') or 'walk_root'in r)]
 entries=[r for r in data if r.get('walk')]
 days=sorted({m.group() for r in entries if (m:=re.search(r'2026[./-](?:0[1-9]|1[0-2])[./-]\d{2}',r['path']))})
 months=sorted({m.group() for r in entries if (m:=re.search(r'/2026/[A-Za-z]+',r['path']))})
 summary={'extracted_content':findings,'wazuh_catalog_entries':len(entries),'wazuh_catalog_months':months,'wazuh_date_names':days,'wazuh_catalog_limits':errors,'all_successful_captures_offline_unchanged':True}
 out=ROOT/'ANALISIS-CONTENIDO.json'
 raw=json.dumps(summary,ensure_ascii=False,indent=2)+'\n'
 if out.exists():assert out.read_text(encoding='utf-8')==raw
 else:out.write_text(raw,encoding='utf-8')
 print(raw)
 print('WAZUH_SELECTED_PATHS')
 for r in entries:
  if any(x in r['path'] for x in ['/_data/archives','/_data/alerts','/_data/ossec','/_data/nodes/0/_state','/_data/nodes/0/indices']):
   if r['path'].count('/')<11:print(r['path'],r['size'])

if __name__=='__main__':main()
