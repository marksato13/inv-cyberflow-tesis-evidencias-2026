"""Solo lectura: dd sin of, ext4 sin mount/replay, no importa código del invitado."""
import collections
import hashlib
import io
import json
import shlex
import stat
import subprocess
import sys
from dissect.volume.disk import Disk
from dissect.volume.lvm import LVM2
from dissect.extfs.extfs import ExtFS

VM={
 'wazuh':(2,'VM-WAZUH',171798691840),
 'zabbix':(10,'VM_ZABBIX',42949672960),
 'suricata':(8,'VM-SURICATA-CYBERFLOW',42949672960),
}
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=12','-o','StrictHostKeyChecking=yes','-i','/home/gadmin/.ssh/francos-red-export','root@esxi-hv-siem']

def emit(data):
 print(json.dumps(data,ensure_ascii=True),flush=True)

def remote(command):
 result=subprocess.run(SSH+[command],capture_output=True,timeout=90)
 if result.returncode: raise RuntimeError(result.stderr.decode(errors='replace'))
 return result.stdout

class RemoteDisk(io.RawIOBase):
 def __init__(self,path,size):
  self.path=path;self.size=size;self.pos=0;self.cache=collections.OrderedDict();self.requests=0;self.bytes=0
 def readable(self):return True
 def seekable(self):return True
 def writable(self):return False
 def tell(self):return self.pos
 def seek(self,offset,whence=0):
  self.pos=offset if whence==0 else (self.pos+offset if whence==1 else self.size+offset)
  if not 0<=self.pos<=self.size:raise ValueError('seek fuera de disco')
  return self.pos
 def block(self,index):
  if index not in self.cache:
   size=min(65536,self.size-index*65536)
   data=remote('dd if='+shlex.quote(self.path)+' bs=65536 skip='+str(index)+' count=1')
   if len(data)!=size:raise IOError('lectura corta '+str((index,len(data),size)))
   self.requests+=1;self.bytes+=len(data);self.cache[index]=data
   if len(self.cache)>512:self.cache.popitem(last=False)
  self.cache.move_to_end(index)
  return self.cache[index]
 def read(self,n=-1):
  n=self.size-self.pos if n<0 else min(n,self.size-self.pos)
  if n>64*1024*1024:raise ValueError('lectura unica excede limite 64MiB')
  chunks=[]
  while n:
   index,offset=divmod(self.pos,65536);data=self.block(index);chunk=data[offset:offset+n]
   chunks.append(chunk);self.pos+=len(chunk);n-=len(chunk)
  return b''.join(chunks)

def fs_candidates(disk):
 for part in Disk(disk).partitions:
  emit({'partition':part.number,'offset':part.offset,'size':part.size,'type':str(part.type)})
  try:
   fs=ExtFS(part.open());yield 'partition-'+str(part.number),fs
   continue
  except Exception as exc: emit({'partition':part.number,'extfs_probe':str(exc)})
  try:
   lvm=LVM2(part.open())
   for vgname,vgdata in lvm.metadata.items():
    if isinstance(vgdata,dict) and 'logical_volumes' in vgdata:
     emit({'lvm_mapping':vgname,'extent_size':vgdata.get('extent_size'),'physical_volume_ids':{n:v.get('id') for n,v in vgdata.get('physical_volumes',{}).items()},'logical_segments':{n:{k:v for k,v in value.items() if k.startswith('segment')} for n,value in vgdata['logical_volumes'].items()}})
     for value in vgdata['logical_volumes'].values():
      for k,v in value.items():
       if k.startswith('segment') and isinstance(v,dict):
        assert v.get('type')=='striped' and v.get('stripe_count')==1,'solo LVM lineal single-stripe admitido'
   for name,lv in lvm.vg.logical_volumes.items():
    emit({'lvm_volume':name})
    try:yield 'lvm-'+name,ExtFS(lv.open())
    except Exception as exc:emit({'lvm_volume':name,'extfs_probe':str(exc)})
  except Exception as exc:emit({'partition':part.number,'lvm_probe':str(exc)})

def metadata(node,path):
 return {'path':path,'inode':node.inum,'size':node.size,'type':node.filetype,'mtime':str(node.mtime)}

def main(params):
 name=params['vm'];vmid,dirname,size=VM[name]
 state=remote('vim-cmd vmsvc/power.getstate '+str(vmid)).decode()
 assert 'Powered off' in state,state
 path='/vmfs/volumes/datastore1/'+dirname+'/'+dirname+'-flat.vmdk'
 before=remote('ls -ln '+shlex.quote(path)).decode()
 disk=RemoteDisk(path,size)
 # Repeat a range read uncached: verifies transport consistency, not whole-disk integrity.
 first=disk.block(0);repeat=remote('dd if='+shlex.quote(path)+' bs=65536 count=1')
 assert first==repeat
 emit({'vm':name,'state_before':state,'disk_path':path,'disk_metadata_before':before,'first64k_sha256':hashlib.sha256(first).hexdigest(),'range_repeat_equal':True,'transport':'ssh dd input-only','journal_replay':False})
 filesystems={}
 for label,fs in fs_candidates(disk):
  filesystems[label]=fs
  emit({'filesystem':label,'uuid':str(fs.uuid),'block_size':fs.block_size,'volume_name':fs.volume_name,'last_mount':fs.last_mount,'s_state':fs.sb.s_state,'feature_incompat':fs.sb.s_feature_incompat})
  if params.get('filesystem') and label!=params['filesystem']:continue
  paths=params.get('paths',['/','/var/log','/var/ossec/logs','/var/ossec/logs/archives','/var/ossec/logs/alerts','/var/ossec/logs/archives/2026/Sep','/var/ossec/logs/alerts/2026/Sep','/var/lib/mysql','/var/lib/postgresql','/var/log/suricata','/var/backups'])
  for target in paths:
   try:
    node=fs.get(target)
    emit({'filesystem':label,**metadata(node,target)})
    if node.filetype==stat.S_IFDIR:
     entries=[]
     for child in node.iterdir():
      if child.filename in ['.','..']:continue
      entries.append(metadata(child,target.rstrip('/')+'/'+child.filename))
      if len(entries)>5000:raise RuntimeError('directorio excede 5000 entradas')
     emit({'filesystem':label,'directory':target,'entries':entries})
    elif params.get('read_files'):
     assert node.filetype==stat.S_IFREG,'no extraer enlaces ni dispositivos'
     assert node.size<=params.get('max_bytes',16*1024*1024),'archivo excede limite'
     content=node.open().read()
     assert len(content)==node.size,'lectura archivo incompleta'
     import base64
     emit({'filesystem':label,'extracted_path':target,'size':len(content),'sha256':hashlib.sha256(content).hexdigest(),'base64':base64.b64encode(content).decode()})
   except Exception as exc:emit({'filesystem':label,'path':target,'error':str(exc)})
  for target in params.get('walk',[]):
   count=[0]
   def walk(node,path,depth):
    for child in node.iterdir():
     if child.filename in ['.','..']:continue
     childpath=path.rstrip('/')+'/'+child.filename
     count[0]+=1
     if count[0]>params.get('walk_limit',2000):raise RuntimeError('limite walk alcanzado')
     emit({'filesystem':label,'walk':True,**metadata(child,childpath)})
     if child.filetype==stat.S_IFDIR and depth>0:walk(child,childpath,depth-1)
   try:walk(fs.get(target),target,params.get('walk_depth',2))
   except Exception as exc:emit({'filesystem':label,'walk_root':target,'error':str(exc)})
  for target in params.get('scan_json',[]):
   try:
    import gzip
    node=fs.get(target)
    assert node.filetype==stat.S_IFREG and node.size<=2*1024*1024
    raw=node.open().read();assert len(raw)==node.size
    content=gzip.decompress(raw) if target.endswith('.gz') else raw
    events=[json.loads(line) for line in content.splitlines() if line.strip()]
    stamps=[str(e.get('timestamp','')) for e in events]
    matching=[e for e in events if str(e.get('timestamp','')).startswith(('2026-09-27','2026-09-28','2026-09-29','2026-09-30'))]
    emit({'filesystem':label,'scanned_json_path':target,'raw_size':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'events':len(events),'timestamp_min':min(stamps,default=''),'timestamp_max':max(stamps,default=''),'september27_30_events':len(matching),'raw_messages_exported':False})
   except Exception as exc:emit({'filesystem':label,'scanned_json_path':target,'error':str(exc)})
 after=remote('ls -ln '+shlex.quote(path)).decode()
 final_state=remote('vim-cmd vmsvc/power.getstate '+str(vmid)).decode()
 assert before==after,'metadatos disco cambiaron'
 assert 'Powered off' in final_state
 emit({'vm':name,'state_after':final_state,'disk_metadata_unchanged':True,'range_requests':disk.requests,'bytes_read':disk.bytes,'complete':True,'complete_meaning':'execution_finished_not_exhaustive_acquisition;review_per_path_errors','not_a_full_disk_hash':True})

main(PARAMS)
