"""Cruce nominal sin predicciones, selección de offsets ni modificación de etiquetas."""
import collections
import csv
import datetime as dt
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "CRUCE-PILOTO-2026-09-30-REVISION-EXTRACTOR"
KEY = ("campaign_id", "entity_ip", "window_end_utc")
BIT1 = "ataques-cyberflow-20260929-193105.txt"
BIT2 = "ataques2-20260929-202246.txt"
EPISODES = [
    ("E1", "nmap", "00:31:05", "00:32:46", BIT1, "2-13", "Salida cliente informa host y puertos; no hay traza por ventana del destino"),
    ("E2", "Nikto1", "00:33:46", "00:35:48", BIT1, "15-29", "Fin interno de Nikto; FIN del script 01:22:37 no es fin del escaneo"),
    ("E3", "Nikto2_timeout", "01:22:46", "01:25:16", BIT2, "3-6", "rc=124; el http_200 de la linea 2 es un chequeo previo, no prueba de trafico Nikto sostenido"),
    ("E4", "HTTP_bucle", "01:25:46", "01:27:46", BIT2, "8-9", "Inicio/fin del generador; sin solicitudes por ventana verificadas en receptor"),
    ("E5", "password_spray", "01:28:16", "01:28:18", BIT2, "11-12", "Episodio de dos segundos; posible mezcla con historia HTTP previa"),
    ("E6", "DNS", "01:28:48", "01:31:00", BIT2, "14-15", "El generador apunta a DMZ; no se recupero log DNS receptor ni pares por paquete"),
]


def timestamp(hms):
    return dt.datetime.fromisoformat("2026-09-30T" + hms + "+00:00")


def save(name, content):
    path = ROOT / name
    if isinstance(content, str):
        content = content.encode("utf-8")
    if path.exists():
        assert path.read_bytes() == content, "Salida existente distinta: " + name
    else:
        path.write_bytes(content)
    print(str(path))


def csv_text(rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue()


def load_csv(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def capture(name):
    record = json.loads((ROOT / (name + ".json")).read_text(encoding="utf-8"))
    return record, [json.loads(line) for line in record["stdout"].splitlines() if line.startswith("{")]


def build():
    original = (OLD / "ataques-nota-M.csv").read_bytes()
    assert hashlib.sha256(original).hexdigest() == "4affd07fff45f97c91eb531f208d76df0410fbb602ea1b13847336dfb0e2803e"
    positives = list(csv.DictReader(io.StringIO(original.decode("utf-8"))))
    reference = load_csv(ROOT / "referencia74-original.csv")
    assert len(positives) == 84 and len(reference) == 74
    assert not ({tuple(r[k] for k in KEY) for r in positives} & {tuple(r[k] for k in KEY) for r in reference})
    s2 = {tuple(r[k] for k in KEY): r for r in load_csv(OLD / "antecedente-s2-piloto.csv")}
    matrix = []
    for group, label, source_rows in [("P", 1, positives), ("R", 0, reference)]:
        for n, row in enumerate(sorted(source_rows, key=lambda r: r["window_end_utc"]), 1):
            end = dt.datetime.fromisoformat(row["window_end_utc"])
            during = [e[0] for e in EPISODES if timestamp(e[2]) <= end <= timestamp(e[3])]
            overlaps = {}
            boundaries = {}
            fully = {}
            for seconds in (10, 30, 60):
                start = end - dt.timedelta(seconds=seconds)
                overlaps[seconds] = [e[0] for e in EPISODES if timestamp(e[2]) <= end and timestamp(e[3]) > start]
                boundaries[seconds] = [e[0] + ":" + tag for e in EPISODES
                                       for time, tag in [(e[2], "inicio"), (e[3], "fin")]
                                       if start < timestamp(time) < end]
                fully[seconds] = [e[0] for e in EPISODES if start >= timestamp(e[2]) and end <= timestamp(e[3])]
            history = overlaps[60]
            links = [f"antecedentes/{e[4]}:L{e[5]}" for e in EPISODES if e[0] in history]
            if group == "R":
                generator_scope = "bitacoras_30sep_fuera_de_fecha;sin_registro_independiente_en_su_fecha"
                temporal = "fuera_de_episodios_conservados_no_prueba_normalidad"
            else:
                generator_scope = "bitacoras_30sep;reloj_sensor_vs_kali_no_calibrado_independientemente"
                temporal = "cierre_dentro_nominal" if during else ("solo_historia_nominal" if history else "sin_intervalo_documentado")
            counterpart = s2.get(tuple(row[k] for k in KEY))
            record = {
                "id": f"{group}{n:03}", "grupo_historico": "positivo" if label else "referencia",
                **{k: row[k] for k in KEY}, "etiqueta_historica_conservada": label,
                "inicio_10s_exclusivo": (end-dt.timedelta(seconds=10)).isoformat(),
                "inicio_30s_exclusivo": (end-dt.timedelta(seconds=30)).isoformat(),
                "inicio_60s_exclusivo": (end-dt.timedelta(seconds=60)).isoformat(),
                **{k: row[k] for k in ["packet_count_10s", "syn_count_10s", "flow_attempt_count_30s", "http_request_count_60s", "dns_query_count_60s"]},
                "episodio_cierre_nominal": ";".join(during), "coincidencia_temporal": temporal,
                **{f"episodios_historia_{s}s_nominal": ";".join(overlaps[s]) for s in (10,30,60)},
                **{f"fronteras_internas_{s}s_nominal": ";".join(boundaries[s]) for s in (10,30,60)},
                **{f"historia_completa_en_episodio_{s}s_nominal": ";".join(fully[s]) for s in (10,30,60)},
                "mezcla_episodios_60s_nominal": int(len(history) > 1),
                "fuente_fila": "antecedentes/ataques-nota-M.csv" if label else "referencia74-original.csv;02-referencia74-original.json",
                "evidencia_episodio_emisor": ";".join(links), "cobertura_emisor": generator_scope,
                "destino_declarado_generador": "10.10.30.10" if history else "",
                "origen_destino_observado_independientemente_en_esta_ventana": "no_recuperado",
                "operacion_receptor_en_esta_ventana": "no_recuperada",
                "evidencia_destino": "27-srvdmz-fechas-de-evento.json;sin_cobertura_eventos_sep27_30",
                "evidencia_firewall_trafico": "18/19-pfsense-lectura-logs;filter.log_solo_nov22",
                "evidencia_firewall_reloj": "NTP_contextual_sin_offset_S1_Kali;sin_ano_zona_en_lineas;config_historica_no_recuperada",
                "evidencia_wazuh": "10/14-wazuh-acceso;SSH_publickey_denegada;archivos_e_indices_no_inspeccionados",
                "evidencia_zabbix": "11/15/22/24;sin_SSH_y_sin_token;historia_no_consultada",
                "evidencia_respaldo": "05/16/21;hv-backup_inventariado;VM_BACKUP_inaccesible;discos_no_inspeccionados",
                "sensor2_packet_count_10s_misma_clave_sin_offset": counterpart["packet_count_10s"] if counterpart else "",
                "sensor2_alcance": "agregado_mismo_SPAN_no_etiqueta_independiente" if counterpart else "sin_fila_en_recorte_conservado_no_prueba_ausencia",
                "offset_aplicado_s": 0, "calibracion_relojes_independiente": "no_recuperada",
                "atribucion_final": "incierta", "normalidad_verificada": "no",
                "etiqueta_nueva": "", "limite": "coincidencia_nominal_no_confirma_semantica;ausencia_de_registro_no_prueba_normalidad",
            }
            matrix.append(record)
    save("MATRIZ-158.csv", csv_text(matrix))
    episode_rows = []
    for e in EPISODES:
        rows = [r for r in matrix if r["grupo_historico"] == "positivo"]
        episode_rows.append({"episodio":e[0],"operacion":e[1],"inicio_kali_utc":timestamp(e[2]).isoformat(),
                             "fin_kali_utc":timestamp(e[3]).isoformat(),"fuente":f"antecedentes/{e[4]}:L{e[5]}",
                             "cierres_nominales":sum(e[0] in r["episodio_cierre_nominal"].split(';') for r in rows),
                             **{f"interseccion_{s}s_nominal":sum(e[0] in r[f"episodios_historia_{s}s_nominal"].split(';') for r in rows) for s in (10,30,60)},
                             **{f"historia_completa_{s}s_nominal":sum(e[0] in r[f"historia_completa_en_episodio_{s}s_nominal"].split(';') for r in rows) for s in (10,30,60)},
                             "ventanas_atribuidas_de_forma_concluyente":0,
                             "interpretacion_cero":"no_se_establecio_atribucion_concluyente;no_significa_cero_ataques", "limite":e[6]})
    save("EPISODIOS-RESUMEN.csv", csv_text(episode_rows))
    log_rows=[]
    log_totals={}
    for name in ["27-srvdmz-fechas-de-evento", "18-pfsense-a-lectura-logs", "19-pfsense-b-lectura-logs"]:
        outer, entries=capture(name)
        assert outer['returncode']==0
        files=[r for r in entries if 'path' in r]
        assert not any('error' in r or 'skipped' in r or r.get('truncated') or r.get('changed_during_read') for r in files)
        log_totals[name]={"files":len(files),"lines":sum(r['lines'] for r in files),"september_candidate_lines":sum(r['september27_30_lines'] for r in files),"relevant_candidate_lines":sum(r['relevant_lines'] for r in files)}
        for r in files:
            log_rows.append({"consulta":name+".json","path_remoto":r['path'],"raw_sha256":r['raw_sha256'],
                             "raw_size":r['raw_size'],"lineas_leidas":r['lines'],"primer_registro":r['first'],
                             "ultimo_registro":r['last'],"lineas_candidatas_sep27_30":r['september27_30_lines'],
                             "lineas_candidatas_origen_destino_reloj":r['relevant_lines'],
                             "limite":"fechas_syslog_sin_ano_zona;contenido_no_prueba_completitud" if 'pfsense' in name else "fecha_de_evento_no_fechas_mencionadas_en_comandos"})
    save("COBERTURA-LOGS.csv",csv_text(log_rows))
    source_rows=[
        {"fuente":"SRV-DMZ", "estado":"sin_cobertura_del_periodo_en_logs_inspeccionados", "capturas":"07;23;27", "detalle":"journal desde 25-oct; 15 logs leidos por completo sin fecha de evento Sep27-30; configuracion actual de web envia stderr al journal", "limite":"configuracion actual no demuestra configuracion historica; no se demuestra inexistencia universal"},
        {"fuente":"pfSense-A", "estado":"evidencia_contextual_recuperada_sin_trafico_piloto", "capturas":"08;18;25", "detalle":"41 archivos; filter.log y rotaciones con Nov22; ntpd/DHCP/resolver conservan algunas lineas de septiembre; syslog apunta actualmente a Wazuh", "limite":"NTP contextual no calibra reloj S1 ni Kali; lineas sin ano/zona; configuracion historica no recuperada"},
        {"fuente":"pfSense-B", "estado":"evidencia_contextual_recuperada_sin_trafico_piloto", "capturas":"09;19;26", "detalle":"34 archivos; filter.log y rotaciones con Nov22; NTP/DHCP/resolver y administracion nginx conservan septiembre", "limite":"no son logs HTTP del destino; sin pares de trafico piloto; falta offset independiente"},
        {"fuente":"Wazuh_10.10.60.10", "estado":"inaccesible_con_accesos_disponibles", "capturas":"10;14;18;19", "detalle":"SSH gadmin/root publickey denegada; receptor syslog configurado actualmente en ambos pfSense", "limite":"archives alerts e indices no inspeccionados; no afirmar ausencia de eventos"},
        {"fuente":"Zabbix_10.10.60.45", "estado":"API_alcanzable_historia_no_autenticada", "capturas":"11;15;20;22;24", "detalle":"API 7.0.32 responde; SSH denegada; TOKEN=None en tres scripts; no se realizo login ni consulta historica autenticada", "limite":"fallo tecnico de primer intento por NoneType preservado; no permite afirmar que historia este vacia"},
        {"fuente":"hv-backup_172.17.25.1", "estado":"inventario_acotado_completado", "capturas":"05;16", "detalle":"VM-BACKUP registrada aqui; snapshot.get sin arbol; busqueda de nombres candidatos profundidad 4 sin resultados", "limite":"no se leyeron VMDK ni catalogos dentro de la VM; reloj actual del host dice 2024, no estima desfase de 2026"},
        {"fuente":"VM-BACKUP_10.10.60.42_172.17.25.30", "estado":"inaccesible_con_accesos_disponibles", "capturas":"05;13;21", "detalle":"IPs verificadas por guest info; management no tiene clave de host conocida y se respeto comprobacion estricta; VLAN60 publickey denegada", "limite":"catalogo y respaldos de invitado no inspeccionados; no montar ni restaurar"},
        {"fuente":"hv-datos_172.17.25.3", "estado":"inaccesible_SSH_connection_refused", "capturas":"06", "detalle":"el inventario conservado del 20-nov no ubica VM-BACKUP aqui", "limite":"no se habilito SSH ni se inspecciono datastore actual; no afirmar ausencia de archivos"},
    ]
    save("FUENTES-Y-LIMITES.csv",csv_text(source_rows))
    lines=["# Matriz de evidencia por ventana: 84 positivas historicas + 74 referencias", "",
           "La matriz CSV contiene todas las columnas de evidencia, cobertura y procedencia. Esta vista resume las 158 filas. Todos los tiempos son nominales, sin offset ni etiquetas nuevas.", "",
           "- P: etiqueta historica positiva; R: etiqueta historica de referencia, normalidad no verificada.",
           "- E1–E6: episodios con bitacora. Coincidencia no equivale a atribucion confirmada.",
           "- F: fronteras estrictamente internas en la historia de 60 s; I/F = inicio/fin. El CSV distingue 10/30/60 s.",
           "- En todas las filas: operacion en receptor y par origen/destino por ventana no recuperados; Wazuh/Zabbix/VM-BACKUP no inspeccionados por falta de acceso autenticado; incertidumbre de reloj sin resolver.",
           "", "| ID | Cierre UTC | Paq/10s | Episodio cierre | Episodios historia 60s | Fronteras 60s | Estado |", "|---|---|---:|---|---|---|---|"]
    for r in matrix:
        lines.append(f"| {r['id']} | {r['window_end_utc']} | {r['packet_count_10s']} | {r['episodio_cierre_nominal'] or '—'} | {r['episodios_historia_60s_nominal'] or '—'} | {r['fronteras_internas_60s_nominal'] or '—'} | incierta |")
    save("MATRIZ-158.md",'\n'.join(lines)+'\n')
    zero_reference=[r for r in reference if float(r['packet_count_10s'])==0]
    history_keys=['flow_attempt_count_30s','http_request_count_60s','dns_query_count_60s']
    summary={"windows":len(matrix),"positive_windows":84,"reference_windows":74,
             "reference_first":min(r['window_end_utc'] for r in reference),"reference_last":max(r['window_end_utc'] for r in reference),
             "reference_active10":74-len(zero_reference),"reference_zero10":len(zero_reference),
             "reference_zero10_with_nonzero_selected_history_counts":sum(any(float(r[k])>0 for k in history_keys) for r in zero_reference),
             "positive_nominal_states":dict(collections.Counter(r['coincidencia_temporal'] for r in matrix if r['grupo_historico']=='positivo')),
             "positive_mixed_history60":sum(r['mezcla_episodios_60s_nominal'] for r in matrix if r['grupo_historico']=='positivo'),
             "all_attributions_remain_uncertain":all(r['atribucion_final']=='incierta' for r in matrix),
             "offsets_applied":[0],"detector_predictions_used":False,"metrics_recomputed":False,"labels_changed":False,
             "logs":log_totals,"episodes":episode_rows}
    save("RESUMEN-VERIFICACION.json",json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


def finalize():
    assert (ROOT/'INFORME-CIERRE-R1.3.md').is_file()
    antecedents=["ataques-nota-M.csv",BIT1,BIT2,"antecedente-kali-journal-piloto.txt",
                 "antecedente-kali-zsh-50-140.txt","antecedente-s2-piloto.csv",
                 "historico-extract_multilayer_v2.py","historico-extract_multilayer_v3.py"]
    archive=ROOT/'EVIDENCIA-FUENTES.zip'
    assert not archive.exists()
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for p in sorted(ROOT.glob('[0-9][0-9]-*.json')):
            out.writestr('capturas/'+p.name,p.read_bytes())
        for name in antecedents:
            out.writestr('antecedentes/'+name,(OLD/name).read_bytes())
    with zipfile.ZipFile(archive) as stored:
        assert stored.testzip() is None
        for name in antecedents:
            assert stored.read('antecedentes/'+name)==(OLD/name).read_bytes()
    names=sorted([p for p in ROOT.iterdir() if p.is_file() and p.name!='MANIFIESTO.json']+[ROOT/'ARCHIVOS.md'])
    listing='# Archivos de la entrega (rutas absolutas)\n\n'+'\n'.join('- `'+str(p)+'`' for p in names)+'\n- `'+str(ROOT/'MANIFIESTO.json')+'`\n'
    save('ARCHIVOS.md',listing)
    manifest={"generated_utc":dt.datetime.now(dt.timezone.utc).isoformat(),
              "source_gold_sha256":"08604ae3754912a17f1e2895fa199b9758bbc0e91a7e9018070953e2f71b6ac1",
              "source_positive_sha256":"4affd07fff45f97c91eb531f208d76df0410fbb602ea1b13847336dfb0e2803e",
              "outputs_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='MANIFIESTO.json'},
              "antecedents_sha256":{name:hashlib.sha256((OLD/name).read_bytes()).hexdigest() for name in antecedents},
              "labels_changed":False,"metrics_changed":False,"manuscript_changed":False,"pushed":False}
    save('MANIFIESTO.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':
    if sys.argv[1:]==['build']: build()
    elif sys.argv[1:]==['finalize']: finalize()
    else: raise SystemExit('Use build o finalize')
