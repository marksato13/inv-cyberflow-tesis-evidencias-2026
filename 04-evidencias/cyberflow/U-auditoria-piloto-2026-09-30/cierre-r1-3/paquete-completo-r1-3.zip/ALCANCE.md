# R1.3 · Alcance cerrado de recuperación de evidencia

## Objetivo

Recuperar únicamente evidencia pendiente de los respaldos identificados y registros históricos del destino, monitorización y firewall. Construir una matriz de las 84 ventanas positivas históricas y las 74 ventanas de referencia de la misma estación. Mantener como inciertas las atribuciones no demostradas.

## Fuentes incluidas

1. Inventario conservado de hv-datos y hv-backup y, si existe acceso de lectura, VM-BACKUP y catálogos/archivos de respaldo pertinentes a los sensores o SRV-DMZ.
2. SRV-DMZ: access/error/auth/syslog/journal históricos, rotaciones y respaldos de esos registros.
3. Wazuh: archivos históricos de eventos y alertas recibidos del piloto; índices/catálogos visibles con acceso ya disponible.
4. Zabbix: registros y retención de historia; solo consultas de lectura si existe acceso ya disponible sin exponer credenciales.
5. pfSense A/B: registros históricos de tráfico, sistema y NTP y archivos/rotaciones de esos registros.
6. Evidencia ya recuperada de Kali y ambos sensores: se reutiliza, sin repetir búsquedas generales. Se consulta el oro original exclusivamente para identificar las 74 claves y sus características, sin leer predicciones.

## Intervalos

- Positivos históricos: 30-sep-2026, 00:00–02:00 UTC, incluyendo 60 s anteriores para las historias de características.
- Las 74 referencias se buscarán en sus tiempos reales una vez extraídas las claves, sin presumir que pertenecen al 30-sep. La cobertura incluirá sus historias de 60 s.
- Se inspeccionarán primero catálogos, rangos y cobertura; una fecha de modificación no demuestra la fecha de los eventos.

## Reglas de cierre

- No ampliar a nuevos dispositivos o almacenes ajenos a los identificados.
- No habilitar SSH, instalar herramientas, restaurar máquinas, montar discos, alterar retención ni cambiar la configuración de ningún host.
- Las autenticaciones y sudo de lectura pueden generar registros de auditoría normales; no se pretende impedir esos registros.
- Cada fuente se cerrará como evidencia recuperada, sin cobertura del periodo en lo inspeccionado, inaccesible, o pendiente por límite técnico explícito. Un fallo de acceso no significa inexistencia.
- No elegir offsets, intervalos ni etiquetas a partir de puntuaciones/predicciones del detector. Sin medición de reloj independiente, comparar timestamps nominales y declarar su incertidumbre.
- No modificar manuscrito, datos originales, etiquetas, modelos o métricas. No recalcular la Tabla 8 en esta fase.
- Este paquete queda local para revisión; esta petición no autoriza por sí sola un nuevo commit o push.
