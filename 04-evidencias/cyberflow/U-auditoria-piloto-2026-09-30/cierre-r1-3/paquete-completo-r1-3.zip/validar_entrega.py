"""Verifica localmente la entrega R1.3; no accede al laboratorio ni carga modelos."""
import collections
import csv
import datetime as dt
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
KEY = ('campaign_id','entity_ip','window_end_utc')


def load(name):
    with (ROOT/name).open(encoding='utf-8',newline='') as stream:
        return list(csv.DictReader(stream))


def main():
    matrix=load('MATRIZ-158.csv')
    reference=load('referencia74-original.csv')
    episodes=load('EPISODIOS-RESUMEN.csv')
    summary=json.loads((ROOT/'RESUMEN-VERIFICACION.json').read_text(encoding='utf-8'))
    gold_capture=json.loads((ROOT/'02-referencia74-original.json').read_text(encoding='utf-8'))
    gold=json.loads(gold_capture['stdout'])
    assert gold['source_sha256']=='08604ae3754912a17f1e2895fa199b9758bbc0e91a7e9018070953e2f71b6ac1'
    assert gold['total_source_rows']==65421
    assert sorted(reference,key=lambda r:r['window_end_utc'])==sorted(gold['selected_rows'],key=lambda r:r['window_end_utc'])
    key=lambda r:tuple(r[k] for k in KEY)
    assert len(matrix)==len({key(r) for r in matrix})==len({r['id'] for r in matrix})==158
    positive=[r for r in matrix if r['grupo_historico']=='positivo']
    normal=[r for r in matrix if r['grupo_historico']=='referencia']
    assert len(positive)==84 and len(normal)==74
    assert {key(r) for r in normal}=={key(r) for r in reference}
    assert all(r['etiqueta_historica_conservada']=='1' for r in positive)
    assert all(r['etiqueta_historica_conservada']=='0' for r in normal)
    assert all(r['etiqueta_nueva']=='' and r['atribucion_final']=='incierta' and r['normalidad_verificada']=='no' and r['offset_aplicado_s']=='0' for r in matrix)
    assert not any(re.search(r'prediction|score|decision_function|y_pred',name,re.I) for name in matrix[0])
    assert dict(collections.Counter(r['coincidencia_temporal'] for r in positive))==summary['positive_nominal_states']
    assert [int(e['cierres_nominales']) for e in episodes]==[10,12,0,12,0,13]
    for row in matrix:
        end=dt.datetime.fromisoformat(row['window_end_utc'])
        for seconds in (10,30,60):
            start=end-dt.timedelta(seconds=seconds)
            assert start.isoformat()==row[f'inicio_{seconds}s_exclusivo']
            expected=[]; interior=[]; boundaries=[]
            for e in episodes:
                a=dt.datetime.fromisoformat(e['inicio_kali_utc'])
                b=dt.datetime.fromisoformat(e['fin_kali_utc'])
                if a<=end and b>start: expected.append(e['episodio'])
                if start>=a and end<=b: interior.append(e['episodio'])
                for time,tag in [(a,'inicio'),(b,'fin')]:
                    if start<time<end: boundaries.append(e['episodio']+':'+tag)
            assert ';'.join(expected)==row[f'episodios_historia_{seconds}s_nominal']
            assert ';'.join(interior)==row[f'historia_completa_en_episodio_{seconds}s_nominal']
            assert ';'.join(boundaries)==row[f'fronteras_internas_{seconds}s_nominal']
    assert sum(int(r['mezcla_episodios_60s_nominal']) for r in positive)==7
    assert len(load('COBERTURA-LOGS.csv'))==90
    assert len(load('FUENTES-Y-LIMITES.csv'))==8
    for p in ROOT.glob('[0-9][0-9]-*.json'):
        d=json.loads(p.read_text(encoding='utf-8'))
        assert hashlib.sha256(d['stdout'].encode('utf-8')).hexdigest()==d['stdout_sha256'],p.name
    archived=0
    if '--preflight' not in sys.argv:
        manifest=json.loads((ROOT/'MANIFIESTO.json').read_text(encoding='utf-8'))
        for name,expected in manifest['outputs_sha256'].items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
        present={p.name for p in ROOT.iterdir() if p.is_file() and p.name!='MANIFIESTO.json'}
        assert present==set(manifest['outputs_sha256'])
        with zipfile.ZipFile(ROOT/'EVIDENCIA-FUENTES.zip') as archive:
            assert archive.testzip() is None
            for name,expected in manifest['antecedents_sha256'].items():
                assert hashlib.sha256(archive.read('antecedentes/'+name)).hexdigest()==expected
            for p in ROOT.glob('[0-9][0-9]-*.json'):
                assert archive.read('capturas/'+p.name)==p.read_bytes()
            original=archive.read('antecedentes/ataques-nota-M.csv')
            assert hashlib.sha256(original).hexdigest()==manifest['source_positive_sha256']
            originals=list(csv.DictReader(io.StringIO(original.decode('utf-8'))))
            assert {key(r) for r in originals}=={key(r) for r in positive}
            log=archive.read('antecedentes/ataques-cyberflow-20260929-193105.txt').decode('utf-8').splitlines()
            assert '2026-09-30T00:31:05+0000' in log[1]
            assert '2026-09-30T00:32:46+0000' in log[12]
            assert '2026-09-29 19:35:48 (GMT-5)' in log[28]
            second=archive.read('antecedentes/ataques2-20260929-202246.txt').decode('utf-8').splitlines()
            assert 'rc=124' in second[5]
            archived=len(archive.namelist())
        print(json.dumps({'all_manifest_hashes_valid':True,'manifest_files':len(manifest['outputs_sha256']),'archive_files':archived},indent=2))
    print(json.dumps({'windows':158,'positive':84,'reference':74,'unique_keys':158,
                      'source_populations_preserved':True,'history_rules_verified':True,
                      'labels_changed':False,'offsets_applied':[0],'predictions_used':False,
                      'metrics_recomputed':False,'log_files_in_coverage_ledger':90,
                      'status':'PASS'},indent=2))


if __name__=='__main__': main()
