"""Adquisición de lectura acotada para R1.3. No ejecuta código del detector."""
import concurrent.futures
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SSH = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=12",
       "-o", "StrictHostKeyChecking=yes", "-i", str(Path.home() / ".ssh/id_ed25519"),
       "gadmin@10.10.10.30"]


def acquire(name, command, user=None, host=None, identity=None, timeout=180):
    inner = command
    if host:
        inner = ("ssh -o BatchMode=yes -o ConnectTimeout=12 -o StrictHostKeyChecking=yes "
                 + ("-i " + identity + " " if identity else "")
                 + user + "@" + host + " " + shlex.quote(command))
    target = ROOT / (name + ".json")
    assert not target.exists(), str(target)
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    try:
        result = subprocess.run(SSH + [inner], capture_output=True, timeout=timeout)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b"", exc.stderr or b"", "timeout"
    record = {"source": (user + "@" + host) if host else "gadmin@10.10.10.30",
              "started_utc": started, "ended_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "command": command, "transport_command": inner, "returncode": code,
              "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
              "stdout": stdout.decode("utf-8", errors="replace"),
              "stderr": stderr.decode("utf-8", errors="replace")}
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"file": str(target), "returncode": code, "stdout_bytes": len(stdout)}, ensure_ascii=False))
    return record


def python_command(source, sudo=False):
    return ("sudo -n " if sudo else "") + "python3 -B -c " + shlex.quote(source)


def discover():
    code = '''from pathlib import Path
import json,subprocess
p=Path.home()/'.ssh/config'
if p.exists():
 for line in p.read_text().splitlines():
  s=line.strip().split(None,1)
  if s and s[0].lower() in ('host','hostname','user','identityfile','proxyjump'):
   print(line)
for alias in ['esxi-hv-datos','esxi-hv-backup','backup','wazuh','zabbix','pfsense-a','pfsense-b']:
 r=subprocess.run(['ssh','-G',alias],capture_output=True,text=True)
 print(json.dumps({'alias':alias,'config':[x for x in r.stdout.splitlines() if x.split(' ',1)[0] in ['hostname','user','identityfile','proxyjump']]}))
'''
    gold = '''from pathlib import Path
import csv,hashlib,io,json
p=Path('/home/m4rk/cyberflow/artifacts/aprendizaje/oro/oro.csv')
raw=p.read_bytes()
rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8'))))
selected=[r for r in rows if r['entity_ip']=='10.10.20.30']
assert len(selected)==74,len(selected)
print(json.dumps({'source_path':str(p),'source_sha256':hashlib.sha256(raw).hexdigest(),'total_source_rows':len(rows),'selected_rows':selected},ensure_ascii=False))
'''
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        jobs = [executor.submit(acquire, "01-descubrimiento-accesos", python_command(code)),
                executor.submit(acquire, "02-referencia74-original", python_command(gold),
                                "m4rk", "10.10.60.11", "~/.ssh/cyberflow-to-sensor")]
        for job in jobs:
            job.result()


def access_inventory():
    data = json.loads(json.loads((ROOT / "02-referencia74-original.json").read_text(encoding="utf-8"))["stdout"])
    rows = sorted(data["selected_rows"], key=lambda r: r["window_end_utc"])
    with (ROOT / "referencia74-original.csv").open("x", encoding="utf-8", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"reference74_first": rows[0]["window_end_utc"],
                      "reference74_last": rows[-1]["window_end_utc"],
                      "campaigns": sorted({r["campaign_id"] for r in rows}),
                      "source_sha256": data["source_sha256"],
                      "active_reference_rows": sum(float(r["packet_count_10s"]) > 0 for r in rows)}, indent=2))
    code = '''from pathlib import Path
import json,subprocess
print(json.dumps({'ssh_identity_filenames':[p.name for p in (Path.home()/'.ssh').iterdir() if p.is_file() and not p.name.endswith('.pub')]}))
for name in ['VM-BACKUP.ad.francos-sac.com','VM-WAZUH.ad.francos-sac.com','VM-ZABBIX.ad.francos-sac.com']:
 r=subprocess.run(['getent','ahostsv4',name],capture_output=True,text=True,timeout=12)
 print(json.dumps({'dns_name':name,'returncode':r.returncode,'addresses':r.stdout}))
'''
    acquire("03-inventario-accesos-pendientes", python_command(code))


def pending_access():
    root_access = '''from pathlib import Path
import json,re
base=Path('/root/.ssh')
print(json.dumps({'root_ssh_files':[p.name for p in base.iterdir() if p.is_file() and not p.name.endswith('.pub')]}))
p=base/'config'
if p.exists():
 for line in p.read_text().splitlines():
  s=line.strip().split(None,1)
  if s and s[0].lower() in ('host','hostname','user','identityfile','proxyjump'): print(line)
for p in Path('/home/gadmin').glob('*.sh'):
 if any(x in p.name.lower() for x in ['backup','wazuh','zabbix','pfsense','z05','pid01']):
  text=p.read_text(errors='replace')
  print(json.dumps({'script':str(p),'ssh_targets':sorted(set(re.findall(r'[A-Za-z0-9_.-]+@(?:10|172)\\.[0-9.]+',text))),'ip_addresses':sorted(set(re.findall(r'(?<![0-9.])(?:10|172)\\.(?:[0-9]+\\.){2}[0-9]+',text)))}))
'''
    # Root configuration is metadata only; private keys and API credentials are never read.
    jobs = [
        ("04-acceso-bastion-root", python_command(root_access, sudo=True), None, None, None),
        ("05-hv-backup-inventario", "date -u; vim-cmd vmsvc/getallvms; vim-cmd vmsvc/get.guest 1; ls -ln /vmfs/volumes/datastore1/VM-BACKUP", "root", "esxi-hv-backup", "~/.ssh/francos-red-export"),
        ("06-hv-datos-acceso", "date -u; vim-cmd vmsvc/getallvms", "root", "esxi-hv-datos", "~/.ssh/francos-red-export"),
        ("07-srvdmz-inventario", python_command(linux_inventory(), sudo=True), "adminsrvdmz", "10.10.30.10", "~/.ssh/cyberflow-to-srv"),
        ("08-pfsense-a-acceso", "id; date -u; ls -lnT /var/log/filter* /var/log/system* /var/log/ntp* /var/log/nginx* /var/log/archives 2>&1", "root", "10.10.10.2", "~/.ssh/id_ed25519"),
        ("09-pfsense-b-acceso", "id; date -u; ls -lnT /var/log/filter* /var/log/system* /var/log/ntp* /var/log/nginx* /var/log/archives 2>&1", "root", "10.10.10.3", "~/.ssh/id_ed25519"),
        ("10-wazuh-acceso", "id; date -u; sudo -n ls -ld /var/ossec/logs/archives /var/ossec/logs/alerts /var/lib/wazuh-indexer /var/lib/wazuh-indexer/nodes", "gadmin", "10.10.60.10", "~/.ssh/id_ed25519"),
        ("11-zabbix-acceso", "id; date -u; sudo -n ls -ld /var/log/zabbix /var/lib/postgresql /var/lib/mysql /var/backups", "gadmin", "10.10.60.45", "~/.ssh/id_ed25519"),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(acquire, *job) for job in jobs]
        for future in futures:
            future.result()


def linux_inventory():
    return '''from pathlib import Path
import json,os,subprocess
for cmd in [['id'],['date','-u','--iso-8601=seconds'],['journalctl','--list-boots','--no-pager'],['journalctl','--utc','--since','2026-09-27 00:00:00','--until','2026-09-30 02:05:00','-u','systemd-timesyncd','-u','chrony','-u','ntp','--no-pager','-o','short-iso-precise']]:
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
 print(json.dumps({'cmd':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}))
for root,depth in [('/var/log',4),('/var/backups',3),('/srv',3),('/opt',3),('/home/adminsrvdmz',3)]:
 if not Path(root).exists(): continue
 for current,dirs,files in os.walk(root):
  if len(Path(current).relative_to(root).parts)>=depth: dirs[:]=[]
  for name in files:
   p=Path(current)/name
   if root=='/var/log' or any(s in str(p).lower() for s in ['backup','access','error','syslog','auth','nginx','apache','202609','2026-09','pcap','eve.','audit']):
    try:
     s=p.stat(); print(json.dumps({'path':str(p),'size':s.st_size,'mtime':s.st_mtime}))
    except OSError as e: print(json.dumps({'path':str(p),'error':str(e)}))
'''


def summarize_inventory():
    for name in ["05-hv-backup-inventario", "06-hv-datos-acceso", "07-srvdmz-inventario", "09-pfsense-b-acceso"]:
        data=json.loads((ROOT/(name+".json")).read_text(encoding="utf-8"))
        print("SOURCE", name, "RC", data["returncode"], "STDERR", data["stderr"])
        if name == "05-hv-backup-inventario":
            for line in data["stdout"].splitlines():
                if any(x in line for x in ["ipAddress =", "network =", "vmdk", "vmsd", "UTC"]): print(line)
        elif name == "07-srvdmz-inventario":
            for line in data["stdout"].splitlines():
                item=json.loads(line)
                if "cmd" in item or any(x in item.get("path", "") for x in ["nginx", "apache", "access", "auth", "backup", "syslog", "audit"]): print(json.dumps(item,ensure_ascii=False))
        else:
            print(data["stdout"])


def further_inventory():
    metadata = '''from pathlib import Path
import json,re
for p in list(Path('/home/gadmin').glob('*.sh'))+list(Path('/home/gadmin').glob('*.py')):
 if any(x in p.name.lower() for x in ['backup','wazuh','zabbix','pfsense','z05','pid01','zbx']):
  text=p.read_text(errors='replace')
  print(json.dumps({'script':str(p),'ssh_targets':sorted(set(re.findall(r'[A-Za-z0-9_.-]+@(?:10|172)\\.[0-9.]+',text))),'ip_addresses':sorted(set(re.findall(r'(?<![0-9.])(?:10|172)\\.(?:[0-9]+\\.){2}[0-9]+',text)))}))
'''
    jobs = [
        ("12-accesos-desde-scripts", python_command(metadata), None, None, None),
        ("13-vm-backup-acceso", "id; date -u; ls -ld /srv /backup /backups /mnt /media /var/backups /etc/bareos /etc/bacula /var/lib/bareos /var/lib/bacula /var/lib/urbackup 2>&1", "root", "172.17.25.30", "~/.ssh/id_ed25519"),
        ("14-wazuh-root-acceso", "id; date -u; ls -ld /var/ossec/logs/archives /var/ossec/logs/alerts /var/lib/wazuh-indexer /var/lib/wazuh-indexer/nodes 2>&1", "root", "10.10.60.10", "~/.ssh/id_ed25519"),
        ("15-zabbix-root-acceso", "id; date -u; ls -ld /var/log/zabbix /var/lib/postgresql /var/lib/mysql /var/backups 2>&1", "root", "10.10.60.45", "~/.ssh/id_ed25519"),
        ("16-hv-backup-catalogo", "vim-cmd vmsvc/snapshot.get 1; find /vmfs/volumes/datastore1 -maxdepth 4 -type f \\( -iname '*.pcap' -o -iname '*.pcapng' -o -iname '*202609*' -o -iname '*2026-09*' -o -iname '*.tgz' -o -iname '*.ova' -o -iname '*.bak' -o -iname '*0000*.vmdk' \\) -exec ls -ln {} \\;", "root", "esxi-hv-backup", "~/.ssh/francos-red-export"),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for future in [executor.submit(acquire, *job) for job in jobs]: future.result()


def historical_scan():
    srv_scan = r'''from pathlib import Path
import json,gzip,hashlib,re,subprocess
date_re=re.compile(r'2026-09-(?:27|28|29|30)|(?:27|28|29|30)/Sep/2026|Sep\s+(?:27|28|29|30)\b')
relevant=re.compile(r'10\.10\.20\.30|10\.10\.30\.10|ntp|timesync|chrony|clock|time.*sync',re.I)
for p in sorted(Path('/var/log').rglob('*')):
 if not p.is_file() or not re.search(r'auth|syslog|kern|daemon|ufw|nginx|apache|http|audit|chrony|ntp|timesync|ppi',str(p),re.I) or p.suffix in ['.journal','.journal~']: continue
 if p.stat().st_size>150_000_000: print(json.dumps({'path':str(p),'skipped':'raw_size_over_150MB'})); continue
 try:
  before=p.stat(); digest=hashlib.sha256(p.read_bytes()).hexdigest()
  op=gzip.open if p.suffix=='.gz' else open
  n=0; first=''; last=''; dated=0; hits=[]; nhit=0
  with op(p,'rt',encoding='utf-8',errors='replace') as stream:
   for n,line in enumerate(stream,1):
    if n==1: first=line.rstrip()
    last=line.rstrip()
    if date_re.search(line):
     dated+=1
     if relevant.search(line):
      nhit+=1
      if len(hits)<5000: hits.append({'line':n,'text':line.rstrip()})
  after=p.stat()
  print(json.dumps({'path':str(p),'raw_sha256':digest,'raw_size':before.st_size,'lines':n,'first':first,'last':last,'september27_30_lines':dated,'relevant_lines':nhit,'hits':hits,'truncated':nhit>len(hits),'changed_during_read':(before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns)}))
 except Exception as e: print(json.dumps({'path':str(p),'error':str(e)}))
for cmd in [['journalctl','--utc','--since','2026-09-27 00:00:00','--until','2026-09-30 02:05:00','--no-pager','-o','short-iso-precise'],['systemctl','list-units','--type=service','--all','--no-pager']]:
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
 if cmd[0]=='systemctl': r.stdout='\n'.join(x for x in r.stdout.splitlines() if re.search('apache|nginx|http|ppi|docker|podman|container',x,re.I))
 print(json.dumps({'cmd':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}))
'''
    pf_scan = r'''
$paths = [];
foreach (['filter.log*','system.log*','ntpd.log*','nginx.log*','resolver.log*','dhcpd.log*'] as $pattern) {
 foreach (glob('/var/log/'.$pattern) as $p) { if (is_file($p)) $paths[]=$p; }
}
sort($paths);
foreach ($paths as $p) {
 $before=stat($p); $h=hash_file('sha256',$p); $f=fopen($p,'r'); $n=0; $first=''; $last=''; $dated=0; $nhit=0; $hits=[];
 while (($line=fgets($f))!==false) {
  $n++; if ($n===1) $first=rtrim($line); $last=rtrim($line);
  if (preg_match('/2026-09-(27|28|29|30)|(?:27|28|29|30)\/Sep\/2026|Sep\s+(27|28|29|30)\b/',$line)) {
   $dated++;
   if (preg_match('/10\.10\.20\.30|10\.10\.30\.10|ntp|clock|sync/i',$line)) { $nhit++; if (count($hits)<5000) $hits[]=['line'=>$n,'text'=>rtrim($line)]; }
  }
 }
 fclose($f); clearstatcache(true,$p); $after=stat($p);
 echo json_encode(['path'=>$p,'raw_size'=>$before['size'],'raw_sha256'=>$h,'lines'=>$n,'first'=>$first,'last'=>$last,'september27_30_lines'=>$dated,'relevant_lines'=>$nhit,'hits'=>$hits,'truncated'=>$nhit>count($hits),'changed_during_read'=>$before['size']!==$after['size']||$before['mtime']!==$after['mtime']]),"\n";
}
foreach (['/cf/conf/config.xml'] as $p) {
 $x=simplexml_load_file($p);
 if ($x!==false) {
  $s=[]; foreach (['remoteserver','remoteserver2','remoteserver3','enable','filter','system','ntpd','sourceip','ipproto'] as $k) { if (isset($x->syslog->$k)) $s[$k]=(string)$x->syslog->$k; }
  echo json_encode(['configuration'=>$p,'current_only'=>true,'timezone'=>(string)$x->system->timezone,'timeservers'=>(string)$x->system->timeservers,'syslog'=>$s]),"\n";
 }
}
foreach (glob('/cf/conf/backup/*') as $p) {
 if (is_file($p)) echo json_encode(['config_backup'=>$p,'size'=>filesize($p),'mtime'=>filemtime($p)]),"\n";
}
'''
    api_metadata = '''from pathlib import Path
import ast,json
for name in ['zbx_ssh22_idp.py','zbx_dependencias_esxi.py','zbx_firmas_suricata.py','z05d_agente_backup.sh']:
 p=Path('/home/gadmin')/name
 if p.suffix!='.py': continue
 t=ast.parse(p.read_text())
 print(json.dumps({'script':str(p),'assignments':[{'names':[ast.unparse(x) for x in n.targets],'value_node':type(n.value).__name__} for n in t.body if isinstance(n,ast.Assign)],'public_api_urls':sorted({n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,str) and n.value.startswith(('http://10.10.60.45','https://10.10.60.45'))}),'credential_file_paths':sorted({n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,str) and ('token' in n.value.lower() or '.zabbix' in n.value.lower()) and n.value.startswith(('/home/','/etc/','/run/'))})}))
'''
    jobs = [
        ("17-srvdmz-lectura-logs", python_command(srv_scan, sudo=True), "adminsrvdmz", "10.10.30.10", "~/.ssh/cyberflow-to-srv"),
        ("18-pfsense-a-lectura-logs", "php -r " + shlex.quote(pf_scan), "root", "10.10.10.2", "~/.ssh/id_ed25519"),
        ("19-pfsense-b-lectura-logs", "php -r " + shlex.quote(pf_scan), "root", "10.10.10.3", "~/.ssh/id_ed25519"),
        ("20-zabbix-api-metadatos", python_command(api_metadata), None, None, None),
        ("21-vm-backup-acceso-vlan60", "id; date -u; ls -ld /srv /backup /backups /mnt /media /var/backups /etc/bareos /etc/bacula /var/lib/bareos /var/lib/bacula /var/lib/urbackup 2>&1", "root", "10.10.60.42", "~/.ssh/francos-red-export"),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for future in [executor.submit(acquire, *job, timeout=240) for job in jobs]: future.result()


def zabbix_history():
    code = r'''from pathlib import Path
import ast,json,urllib.request,ssl,datetime as dt,re
tree=ast.parse(Path('/home/gadmin/zbx_ssh22_idp.py').read_text())
values={}
for n in tree.body:
 if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant):
  for target in n.targets:
   if isinstance(target,ast.Name) and target.id in ['URL','TOKEN']: values[target.id]=n.value.value
url=values['URL']; token=values.get('TOKEN','')
assert url=='https://10.10.60.45/api_jsonrpc.php'
context=ssl._create_unverified_context()
def call(method,params,auth=True):
 assert method=='apiinfo.version' or method.endswith('.get'),method
 headers={'Content-Type':'application/json-rpc'}
 if auth: headers['Authorization']='Bearer '+token
 body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode()
 req=urllib.request.Request(url,data=body,headers=headers)
 with urllib.request.urlopen(req,context=context,timeout=40) as response: result=json.load(response)
 if 'error' in result: raise RuntimeError(json.dumps({'method':method,'error':result['error']}))
 return result['result']
print(json.dumps({'api_version':call('apiinfo.version',{},False),'credential_source':'existing TOKEN assignment; value never exported','tls':'existing private-lab self-signed context'}))
hosts=call('host.get',{'output':['hostid','host','name'],'selectInterfaces':['ip','dns']})
allowed={'10.10.20.30','10.10.30.10','10.10.60.11','10.10.60.12','10.10.60.10','10.10.60.45','10.10.60.42','10.10.10.2','10.10.10.3'}
hosts=[h for h in hosts if any(i.get('ip') in allowed for i in h.get('interfaces',[])) or re.search(r'kali|srv.?dmz|sensor[12]|pfsense|vm.?backup',h['host'],re.I)]
print(json.dumps({'selected_hosts':hosts}))
ids=[h['hostid'] for h in hosts]
items=call('item.get',{'hostids':ids,'output':['itemid','hostid','name','key_','value_type','history','trends','delay','status']}) if ids else []
pattern=re.compile(r'localtime|clock|ntp|timesync|log\[|logrt\[|system\.uptime|net\.if\.(in|out)|icmpping',re.I)
items=[i for i in items if pattern.search(i['key_']+' '+i['name'])]
print(json.dumps({'relevant_item_catalog':items,'catalog_is_current_not_historical':True}))
start=int(dt.datetime(2026,9,27,tzinfo=dt.timezone.utc).timestamp())
end=int(dt.datetime(2026,9,30,2,5,tzinfo=dt.timezone.utc).timestamp())
for kind in range(5):
 group=[i for i in items if int(i['value_type'])==kind]
 if not group: continue
 params={'history':kind,'itemids':[i['itemid'] for i in group],'time_from':start,'time_till':end}
 count=call('history.get',{**params,'countOutput':True})
 oldest=call('history.get',{'history':kind,'itemids':params['itemids'],'output':['itemid','clock'],'sortfield':'clock','sortorder':'ASC','limit':1})
 print(json.dumps({'history_type':kind,'scoped_items':len(group),'time_from':start,'time_till':end,'historical_count':count,'oldest_retained_sample':oldest}))
 if int(count)>0:
  samples=call('history.get',{**params,'output':'extend','sortfield':'clock','sortorder':'ASC','limit':20000})
  print(json.dumps({'history_type':kind,'historical_records':samples,'truncated':int(count)>len(samples)}))
'''
    acquire("22-zabbix-historia-api", python_command(code), timeout=300)


def scan_summary():
    for name in ["17-srvdmz-lectura-logs", "18-pfsense-a-lectura-logs", "19-pfsense-b-lectura-logs"]:
        data=json.loads((ROOT/(name+".json")).read_text(encoding="utf-8"))
        entries=[json.loads(s) for s in data['stdout'].splitlines() if s.startswith('{')]
        files=[r for r in entries if 'path' in r]
        print(json.dumps({'source':name,'files':len(files),'lines_scanned':sum(r.get('lines',0) for r in files),'september_lines':sum(r.get('september27_30_lines',0) for r in files),'relevant_lines':sum(r.get('relevant_lines',0) for r in files),'errors':[r for r in files if 'error' in r or 'skipped' in r],'changed':[r['path'] for r in files if r.get('changed_during_read')],'stderr':data['stderr']},ensure_ascii=False))
        for r in entries:
            if r.get('relevant_lines') or r.get('september27_30_lines') or 'configuration' in r or 'cmd' in r:
                print(json.dumps(r,ensure_ascii=False))
        for r in files:
            if any(x in r['path'] for x in ['auth.log.4','syslog.4','filter.log.6','system.log.6','nginx.log.5','nginx.log.6','ntpd.log']):
                print(json.dumps({k:r[k] for k in ['path','first','last','lines'] if k in r},ensure_ascii=False))


def final_inspection():
    web = '''import subprocess,json
cmd=['systemctl','show','lab-web-http.service','lab-web-https.service','-p','StandardOutput','-p','StandardError','-p','LogsDirectory','-p','FragmentPath','-p','WorkingDirectory']
r=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
print(json.dumps({'cmd':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'current_configuration_only':True}))
'''
    credential = '''from pathlib import Path
import ast,json
out=[]
for name in ['zbx_ssh22_idp.py','zbx_dependencias_esxi.py','zbx_firmas_suricata.py']:
 tree=ast.parse((Path('/home/gadmin')/name).read_text())
 found=[]
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TOKEN' for t in node.targets) and isinstance(node.value,ast.Constant):
   v=node.value.value; found.append({'configured_token_exists':isinstance(v,str) and bool(v),'value_type':type(v).__name__})
 out.append({'script':name,'token_configuration':found})
print(json.dumps({'existing_token_status':out,'no_login_performed':True,'no_history_query_completed':True}))
'''
    historical_config = r'''
$all=glob('/cf/conf/backup/*'); sort($all); $selected=[];
foreach($all as $p) { if (preg_match('/config-(\d+)\.xml$/',$p,$m)) { $epoch=(int)$m[1]; if ($epoch <= 1790733900) $selected[]=$p; } }
$selected=array_slice($selected,-2);
foreach($selected as $p) {
 $x=simplexml_load_file($p); if($x===false) continue;
 $s=[]; foreach(['remoteserver','remoteserver2','enable','filter','system'] as $k) { if(isset($x->syslog->$k)) $s[$k]=(string)$x->syslog->$k; }
 echo json_encode(['historical_configuration'=>$p,'sha256'=>hash_file('sha256',$p),'revision_time'=>(string)$x->revision->time,'timezone'=>(string)$x->system->timezone,'timeservers'=>(string)$x->system->timeservers,'syslog'=>$s]),"\n";
}
echo json_encode(['configuration_backup_count'=>count($all),'selected_before_pilot_end'=>count($selected),'oldest_filename'=>$all[0]??null,'newest_filename'=>end($all)?:null]),"\n";
'''
    jobs = [
        ("23-srvdmz-destino-logs-servicio", python_command(web, sudo=True), "adminsrvdmz", "10.10.30.10", "~/.ssh/cyberflow-to-srv"),
        ("24-zabbix-limite-autenticacion", python_command(credential), None, None, None),
        ("25-pfsense-a-configuracion-historica", "php -r " + shlex.quote(historical_config), "root", "10.10.10.2", "~/.ssh/id_ed25519"),
        ("26-pfsense-b-configuracion-historica", "php -r " + shlex.quote(historical_config), "root", "10.10.10.3", "~/.ssh/id_ed25519"),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for future in [executor.submit(acquire, *job) for job in jobs]: future.result()


def concise_summary():
    for name in ["17-srvdmz-lectura-logs", "18-pfsense-a-lectura-logs", "19-pfsense-b-lectura-logs"]:
        data=json.loads((ROOT/(name+".json")).read_text(encoding="utf-8"))
        entries=[json.loads(s) for s in data['stdout'].splitlines() if s.startswith('{')]
        files=[r for r in entries if 'path' in r]
        print(json.dumps({'source':name,'files':len(files),'lines_scanned':sum(r.get('lines',0) for r in files),'september_lines':sum(r.get('september27_30_lines',0) for r in files),'relevant_lines':sum(r.get('relevant_lines',0) for r in files),'errors':[r for r in files if 'error' in r or 'skipped' in r],'changed':[r['path'] for r in files if r.get('changed_during_read')],'stderr':data['stderr']},ensure_ascii=False))
        for r in files:
            if r.get('relevant_lines') or any(x in r['path'] for x in ['auth.log.4','syslog.4','filter.log.6']):
                print(json.dumps({k:r[k] for k in ['path','first','last','lines','september27_30_lines','relevant_lines'] if k in r},ensure_ascii=False))
    for name in ['23-srvdmz-destino-logs-servicio','24-zabbix-limite-autenticacion','25-pfsense-a-configuracion-historica','26-pfsense-b-configuracion-historica']:
        p=ROOT/(name+'.json')
        if p.exists():
            d=json.loads(p.read_text(encoding='utf-8')); print(name,d['stdout'],d['stderr'])


def verify_event_dates():
    # A date mentioned in a sudo command body is not the timestamp of that event.
    code = next(c for c in historical_scan.__code__.co_consts
                if isinstance(c,str) and 'date_re=re.compile' in c and 'import json,gzip' in c)
    code = code.replace("if date_re.search(line):", "if date_re.match(line):")
    acquire("27-srvdmz-fechas-de-evento", python_command(code, sudo=True),
            "adminsrvdmz", "10.10.30.10", "~/.ssh/cyberflow-to-srv", timeout=240)


if __name__ == "__main__":
    if sys.argv[1:] == ["discover"]:
        discover()
    elif sys.argv[1:] == ["access-inventory"]:
        access_inventory()
    elif sys.argv[1:] == ["pending-access"]:
        pending_access()
    elif sys.argv[1:] == ["summarize-inventory"]:
        summarize_inventory()
    elif sys.argv[1:] == ["further-inventory"]:
        further_inventory()
    elif sys.argv[1:] == ["historical-scan"]:
        historical_scan()
    elif sys.argv[1:] == ["zabbix-history"]:
        zabbix_history()
    elif sys.argv[1:] == ["scan-summary"]:
        scan_summary()
    elif sys.argv[1:] == ["final-inspection"]:
        final_inspection()
    elif sys.argv[1:] == ["concise-summary"]:
        concise_summary()
    elif sys.argv[1:] == ["verify-event-dates"]:
        verify_event_dates()
    else:
        raise SystemExit("Modo todavía no definido")
